import 'package:accordion/accordion.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:openzo_frontend/constants/constants.dart';
import 'package:openzo_frontend/models/product.dart';
import 'package:openzo_frontend/models/sale.dart';
import 'package:openzo_frontend/src/product/product_card.dart';
import 'package:openzo_frontend/src/product/serviceCard.dart';
import 'package:openzo_frontend/src/product/verticalProductCard.dart';

class ProductsList extends StatelessWidget {
  const ProductsList({
    super.key,
    required this.categories,
    required this.cart,
    this.storeType,
    this.addableToCart = false,
  });

  final Map<String, List<Product>> categories;
  final Sale? cart;
  final StoreType? storeType;
  final bool addableToCart;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
          decoration: BoxDecoration(color: Colors.blueGrey.shade50),
          child: Accordion(
              disableScrolling: true,
              openAndCloseAnimation: false,
              contentBorderColor: Colors.transparent,
              headerBorderRadius: 0,
              headerBackgroundColor: Colors.white,
              paddingListHorizontal: 0,
              headerPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              contentVerticalPadding: 0,
              rightIcon: const Icon(
                Icons.arrow_drop_down,
                size: 32,
              ),
              maxOpenSections: 10,
              children: categories.keys
                  .map(
                    (e) => AccordionSection(
                      isOpen: true,
                      header: Text(
                        e,
                        style: GoogleFonts.poppins(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      content: Container(
                        color: Colors.grey.shade50,
                        // color: Colors.red,
                        padding: EdgeInsets.zero,
                        // color: Colors.black,
                        child: storeType == StoreType.food
                            ? ListView(
                                shrinkWrap: true,
                                padding: EdgeInsets.zero,
                                physics: const NeverScrollableScrollPhysics(),
                                children: [
                                  ...categories[e]!.map((e) => Padding(
                                        padding: const EdgeInsets.all(1.5),
                                        child: ProductCard(
                                          product: e,
                                          cart: cart,
                                          addableToCart: addableToCart,
                                          // addable: addableToCart,
                                        ),
                                      ))
                                ],
                              )
                            : storeType == StoreType.service
                                ? ListView(
                                    shrinkWrap: true,
                                    padding: EdgeInsets.zero,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    children: [
                                      ...categories[e]!.map((e) => Padding(
                                            padding: const EdgeInsets.all(1.5),
                                            child: ServiceCard(
                                              product: e,

                                              // addable: addableToCart,
                                            ),
                                          ))
                                    ],
                                  )

                                // child: ListView(
                                //   // shrinkWrap: true,
                                //   scrollDirection: Axis.horizontal,

                                //   padding: EdgeInsets.zero,
                                //   // physics:
                                //   //     const NeverScrollableScrollPhysics(),
                                //   children: [
                                //     ...categories[e]!.map((e) => Padding(
                                //           padding:
                                //               const EdgeInsets.all(1.5),
                                //           child: ProductCard(
                                //             product: e,
                                //             cart: cart,
                                //             addableToCart: addableToCart,
                                //             // addable: addableToCart,
                                //           ),
                                //         ))
                                //   ],
                                // ),
                                : GridView.builder(
                                    padding: const EdgeInsets.all(0.0),
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      childAspectRatio: 0.56,
                                    ),
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemCount: categories[e]!.length,
                                    itemBuilder: (context, index) {
                                      return Padding(
                                        padding: const EdgeInsets.all(1.5),
                                        child: VerticalProductCard(
                                          product: categories[e]![index],

                                          // cart: cart!,
                                        ),
                                      );
                                    },
                                  ),
                      ),
                    ),
                  )
                  .toList())),
    );
  }
}
