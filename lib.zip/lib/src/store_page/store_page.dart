import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:openzo_frontend/constants/constants.dart';
import 'package:openzo_frontend/models/product.dart';
import 'package:openzo_frontend/models/sale.dart';
import 'package:openzo_frontend/models/store.dart';
import 'package:openzo_frontend/providers/sales_provider.dart';
import 'package:openzo_frontend/src/store_page/Reviews.dart';
import 'package:openzo_frontend/src/store_page/custom_search_delegate.dart';
import 'package:openzo_frontend/src/store_page/productsList.dart';
import 'package:openzo_frontend/src/store_page/productsListSkeleton.dart';
import 'package:openzo_frontend/src/store_page/storeDetails.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class StorePage extends StatefulWidget {
  final String storeId;

  const StorePage({super.key, required this.storeId});

  @override
  State<StorePage> createState() => _StorePageState();
}

class _StorePageState extends State<StorePage>
    with SingleTickerProviderStateMixin {
  late Future<List<Product>> productData;
  late Future<Store> storeData;
  late TabController _tabController;
  int pageIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    productData = Product.fetchMany(widget.storeId);
    storeData = Store.fetchStore(widget.storeId);
  }

  Map<String, List<Product>> categorizeProducts(List<Product> products) {
    return products.fold<Map<String, List<Product>>>({}, (categories, product) {
      if (categories.containsKey(product.category)) {
        categories[product.category]!.add(product);
      } else {
        categories[product.category] = [product];
      }
      return categories;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Sale cart =
        Provider.of<SalesProvider>(context).getSaleByStoreId(widget.storeId);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        bottomNavigationBar: pageIndex == 0
            ? _buildBottomNavigationBar(cart)
            : AddReviewButton(storeId: widget.storeId),
        body: NestedScrollView(
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return <Widget>[
              _buildSliverAppBar(),
              SliverPersistentHeader(
                pinned: true,
                delegate: _SliverAppBarDelegate(
                  TabBar(
                    controller: _tabController,
                    onTap: (index) => setState(() {
                      pageIndex = index;
                    }),
                    tabs: const [
                      Tab(text: 'Products'),
                      Tab(text: 'Reviews'),
                    ],
                  ),
                ),
              ),
            ];
          },
          body: _buildBody(),
        ),
      ),
    );
  }

  Widget _buildBottomNavigationBar(Sale cart) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: cart.id.isNotEmpty
          ? Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Total: ${cart.totalAmount}'),
                ElevatedButton(
                  onPressed: () {
                    context.go('/cart/${cart.id}');
                  },
                  child: const Row(
                    children: [
                      Text(
                        'View Cart',
                      ),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_forward_outlined),
                    ],
                  ),
                ),
              ],
            )
          : const SizedBox.shrink(),
    );
  }

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.white,
      iconTheme: const IconThemeData(color: Colors.black),
      expandedHeight: MediaQuery.of(context).size.width + 140.0,
      floating: false,
      pinned: true,
      shadowColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: FlexibleSpaceBar(
        background: StoreDetails(
          storeData: storeData,
          widget: widget,
          products: [],
        ),
      ),
      actions: [
        FutureBuilder(
            future: productData,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox.shrink();
              } else if (snapshot.hasError) {
                return const SizedBox.shrink();
              } else if (snapshot.hasData) {
                final products = snapshot.data!;
                return IconButton(
                  onPressed: () {
                    showSearch(
                      context: context,
                      delegate: CustomSearchDelegate(products),
                    );
                  },
                  icon: const Icon(Icons.search),
                );
              } else {
                return const SizedBox.shrink();
              }
            }),
        IconButton(
          onPressed: () {
            launchUrl(
              Uri.parse("https://maps.app.goo.gl/Wa1EP6fwMdep2vYn7"),
              mode: LaunchMode.externalApplication,
            );
          },
          icon: const Icon(Icons.location_on_sharp),
        ),
      ],
    );
  }

  Widget _buildBody() {
    final Sale cart =
        Provider.of<SalesProvider>(context).getSaleByStoreId(widget.storeId);
    return FutureBuilder<List<Product>>(
      future: productData,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const ProductListSkeleton();
        } else if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        } else if (snapshot.hasData) {
          final products = snapshot.data!;
          final categories = categorizeProducts(products);
          if (pageIndex == 0) {
            return FutureBuilder<Store>(
              future: storeData,
              builder: (context, storeSnapshot) {
                if (storeSnapshot.connectionState == ConnectionState.waiting) {
                  return const ProductListSkeleton();
                } else if (storeSnapshot.hasError) {
                  return Center(child: Text('Error: ${storeSnapshot.error}'));
                } else if (storeSnapshot.hasData) {
                  return ProductsList(
                    categories: categories,
                    storeType: GlobalConsts.categories
                        .firstWhere(
                          (element) =>
                              element.name == storeSnapshot.data!.category,
                          orElse: () => GlobalConsts.categories[0],
                        )
                        .type,
                    cart: cart,
                    addableToCart: storeSnapshot.data!.selfDeliveryService,
                  );
                } else {
                  return const Center(child: Text('No store data available'));
                }
              },
            );
          } else {
            return ReviewsList(
              storeId: widget.storeId,
              storeData: storeData,
            );
          }
        } else {
          return const Center(child: Text('No products available'));
        }
      },
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar _tabBar;

  _SliverAppBarDelegate(this._tabBar);

  @override
  double get minExtent => _tabBar.preferredSize.height;

  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Colors.white,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}
