// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:image_fade/image_fade.dart';
// import 'package:openzo_frontend/models/cart.dart';
// import 'package:openzo_frontend/models/product.dart';
// import 'package:openzo_frontend/models/sale.dart';
// import 'package:openzo_frontend/providers/sales_provider.dart';
// import 'package:openzo_frontend/utils/capitalize.dart';
// import 'package:provider/provider.dart';

// class VerticalProductCard extends StatefulWidget {
//   Product product;
//   Cart? cart;
//   bool addable = true;
//   VerticalProductCard({
//     super.key,
//     required this.product,
//     this.cart,
//     this.addable = true,
//   });

//   @override
//   State<VerticalProductCard> createState() => _VerticalProductCardState();
// }

// class _VerticalProductCardState extends State<VerticalProductCard> {
//   int quantity = 0;

//   @override
//   void didChangeDependencies() {
//     quantity = widget.cart != null
//         ? widget.cart!.orderItems
//             .firstWhere((element) => element.productId == widget.product.id,
//                 orElse: () => OrderItem(
//                       quantity: 0,
//                       productId: widget.product.id,
//                       // quantity: 0,
//                       id: 0,
//                       orderId: "",
//                     ))
//             .quantity
//         : 0;

//     super.didChangeDependencies();
//   }

//   @override
//   Widget build(BuildContext context) {
//     Widget addButton = widget.addable
//         ? Row(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Container(
//                 padding:
//                     const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
//                 decoration: BoxDecoration(
//                   border: Border.all(color: Colors.grey.shade300),
//                   color: Colors.blueGrey.shade900,
//                   borderRadius: BorderRadius.circular(10.0),
//                 ),
//                 child: quantity != 0
//                     ? Row(children: [
//                         InkWell(
//                           onTap: () {
//                             setState(() {
//                               quantity--;
//                               Provider.of<SalesProvider>(context, listen: false)
//                                   .updateSaleOrderItems(
//                                       widget.product, null, null, quantity);
//                             });
//                           },
//                           child: const Icon(
//                             Icons.remove,
//                             color: Colors.white,
//                           ),
//                         ),
//                         const SizedBox(
//                           width: 10,
//                         ),
//                         Text('$quantity',
//                             style: const TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 16,
//                                 fontWeight: FontWeight.bold)),
//                         const SizedBox(
//                           width: 10,
//                         ),
//                         InkWell(
//                           onTap: () {
//                             setState(() {
//                               quantity++;
//                               Provider.of<SalesProvider>(context, listen: false)
//                                   .updateSaleOrderItems(
//                                       widget.product, null, null, quantity);
//                             });
//                           },
//                           child: const Icon(
//                             Icons.add,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ])
//                     : InkWell(
//                         onTap: () {
//                           setState(() {
//                             // Provider.of<CartsProvider>(context, listen: false).
//                             quantity++;
//                             Provider.of<SalesProvider>(context, listen: false)
//                                 .updateSaleOrderItems(
//                                     widget.product, null, null, quantity);
//                           });
//                         },
//                         child: const Text(
//                           'ADD',
//                           style: TextStyle(
//                             color: Colors.white,
//                             fontSize: 16,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         )),
//               ),
//             ],
//           )
//         : const SizedBox();
//     return Container(
//       color: Colors.white,
//       // height: 205,
//       // width: 320,
//       child: Column(
//         children: [
//           InkWell(
//             onTap: () {
//               showModalBottomSheet(
//                   backgroundColor: Colors.white,
//                   // showDragHandle: true,
//                   shape: const RoundedRectangleBorder(
//                     borderRadius: BorderRadius.only(
//                       topLeft: Radius.circular(20),
//                       topRight: Radius.circular(20),
//                     ),
//                   ),
//                   barrierColor: Colors.grey.withOpacity(0.5),
//                   context: context,
//                   builder: (context) {
//                     return Container(
//                       // height: double.,
//                       padding: const EdgeInsets.only(top: 24),
//                       decoration: const BoxDecoration(
//                         color: Colors.white,
//                         borderRadius: BorderRadius.only(
//                           topLeft: Radius.circular(20),
//                           topRight: Radius.circular(20),
//                         ),
//                       ),
//                       child: Column(
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           CarouselSlider(
//                             options: CarouselOptions(
//                               enableInfiniteScroll: false,
//                               height: 200.0,
//                               autoPlay: true,
//                               autoPlayInterval: const Duration(seconds: 3),
//                               autoPlayAnimationDuration:
//                                   const Duration(milliseconds: 800),
//                               autoPlayCurve: Curves.fastOutSlowIn,
//                               pauseAutoPlayOnTouch: true,
//                               aspectRatio: 2.0,
//                               onPageChanged: (index, reason) {
//                                 // setState(() {
//                                 //   _current = index;
//                                 // });
//                               },
//                             ),
//                             items: widget.product.images
//                                 .map((e) => e.image)
//                                 .map((i) {
//                               return Builder(
//                                 builder: (BuildContext context) {
//                                   return Padding(
//                                     padding: const EdgeInsets.all(8.0),
//                                     child: Container(
//                                       width: 200,
//                                       margin: const EdgeInsets.symmetric(
//                                           horizontal: 5.0),
//                                       decoration: BoxDecoration(
//                                         boxShadow: [
//                                           BoxShadow(
//                                             color: Colors.grey.withOpacity(0.5),
//                                             spreadRadius: 1,
//                                             blurRadius: 1,
//                                             offset: const Offset(0,
//                                                 3), // changes position of shadow
//                                           ),
//                                         ],
//                                         borderRadius:
//                                             BorderRadius.circular(10.0),
//                                         image: DecorationImage(
//                                           image: NetworkImage(i),
//                                           fit: BoxFit.cover,
//                                         ),
//                                       ),
//                                       // child: Image.asset(
//                                       //   i,
//                                       //   fit: BoxFit.cover,
//                                       // ),
//                                     ),
//                                   );
//                                 },
//                               );
//                             }).toList(),
//                           ),
//                           const SizedBox(height: 10),
//                           Text(
//                             widget.product.name,
//                             style: TextStyle(
//                               fontSize: 20,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.blueGrey.shade900,
//                             ),
//                           ),
//                           const SizedBox(height: 10),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             children: [
//                               Text(
//                                 '₹ ${widget.product.mrp}',
//                                 style: const TextStyle(
//                                   fontSize: 20,
//                                   fontWeight: FontWeight.w500,
//                                 ),
//                               ),
//                               const SizedBox(width: 24),
//                               addButton,
//                             ],
//                           ),
//                           const SizedBox(height: 10),
//                           Text(
//                             widget.product.description,
//                             style: const TextStyle(
//                               fontSize: 16,
//                               fontWeight: FontWeight.w400,
//                               color: Colors.grey,
//                             ),
//                           ),
//                         ],
//                       ),
//                     );
//                   });
//             },
//             child: Padding(
//               padding: const EdgeInsets.all(0),
//               // padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
//               child: Column(
//                 //mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   SizedBox(
//                     // height: MediaQuery.of(context).size.width * 0.25,
//                     // width: MediaQuery.of(context).size.width * 0.25,
//                     height: MediaQuery.of(context).size.width * 0.5 * 1.33 - 16,
//                     width: MediaQuery.of(context).size.width * 0.5 - 16,
//                     child: widget.product.images.isNotEmpty
//                         ? ImageFade(
//                             image: NetworkImage(widget.product.images[0].image),
//                             fit: BoxFit.cover,
//                             placeholder: Container(
//                               decoration: BoxDecoration(
//                                 // color: Colors.white,
//                                 color: const Color(0xFFCFCDCA),
//                                 borderRadius: BorderRadius.circular(10.0),
//                               ),
//                               alignment: Alignment.center,
//                               child: Icon(Icons.photo,
//                                   color: Colors.grey.shade300, size: 32),
//                             ),
//                           )
//                         : Container(
//                             decoration: BoxDecoration(
//                               // color: Colors.white,
//                               color: const Color(0xFFCFCDCA),
//                               borderRadius: BorderRadius.circular(10.0),
//                             ),
//                             alignment: Alignment.center,
//                             child: Icon(Icons.photo,
//                                 color: Colors.grey.shade300, size: 32),
//                           ),
//                     // decoration: BoxDecoration(
//                     //     color: Colors.white,
//                     //     // borderRadius: BorderRadius.circular(10.0),
//                     //     image: widget.product.images.isNotEmpty
//                     //         ? DecorationImage(
//                     //             // image: AssetImage('assets/images/watch.webp'),
//                     //             image: NetworkImage(
//                     //                 widget.product.images[0].image),
//                     //             fit: BoxFit.cover,
//                     //           )
//                     //         : const DecorationImage(
//                     //             image: AssetImage('assets/images/watch.webp'))),
//                   ),
//                   const SizedBox(
//                     height: 8,
//                   ),
//                   SizedBox(
//                     width: MediaQuery.of(context).size.width * 0.6,
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           // widget.product.name.length > 20
//                           //     ? '${widget.product.name.substring(0, 20)}...'
//                           //     : widget.product.name,
//                           capitalize(widget.product.name),
//                           style: TextStyle(
//                             fontSize: 14,
//                             fontWeight: FontWeight.w600,
//                             color: Colors.blueGrey.shade900,
//                             fontStyle: GoogleFonts.montserrat().fontStyle,
//                           ),
//                         ),
//                         widget.product.mrp != widget.product.discountPrice
//                             ? Row(
//                                 mainAxisAlignment: MainAxisAlignment.start,
//                                 children: [
//                                   widget.product.mrp !=
//                                           widget.product.discountPrice
//                                       ? Text(
//                                           ' ${(((widget.product.mrp - widget.product.discountPrice) / widget.product.mrp) * 100).toInt()}%',
//                                           style: const TextStyle(
//                                             fontSize: 14,
//                                             fontWeight: FontWeight.w400,
//                                             color: Colors.green,
//                                           ))
//                                       : const Text(""),
//                                   const SizedBox(width: 5),
//                                   Text(
//                                     '${widget.product.mrp}',
//                                     style: const TextStyle(
//                                       fontSize: 14,
//                                       fontWeight: FontWeight.w400,
//                                       color: Colors.grey,
//                                       decoration: TextDecoration.lineThrough,
//                                     ),
//                                   ),
//                                   const SizedBox(width: 5),
//                                   Text(
//                                     '₹${widget.product.discountPrice}',
//                                     style: const TextStyle(
//                                       fontSize: 14,
//                                       fontWeight: FontWeight.w600,
//                                       // color: Colors.,
//                                     ),
//                                   ),
//                                 ],
//                               )
//                             : Text(
//                                 '₹ ${widget.product.mrp}',
//                                 style: const TextStyle(
//                                   fontSize: 14,
//                                   fontWeight: FontWeight.w500,
//                                 ),
//                               ),
//                         // Text(
//                         //   widget.product.description,
//                         //   style: const TextStyle(
//                         //     fontSize: 14,
//                         //     fontWeight: FontWeight.w400,
//                         //     color: Colors.grey,
//                         //   ),
//                         // ),
//                       ],
//                     ),
//                   ),
//                   addButton,
//                 ],
//               ),
//             ),
//           ),
//           // addButton,
//         ],
//       ),
//     );
//   }
// }
